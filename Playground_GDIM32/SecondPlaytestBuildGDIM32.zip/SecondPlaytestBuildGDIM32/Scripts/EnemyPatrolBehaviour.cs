using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyPatrolBehaviour : MonoBehaviour
{

    // Script by: Markesha Big

    // This is the enemy patrol state of the enemy.

    // Creating a transform for the way points index.

    public Transform[] enemyWayPoints;

    // Enemy idle time.

    public float idleWaitTime;

    // The enemy's current waypoint index.

    int currentEnemyWPIndex;

    void Update()
    {



    }
}
